</div>
<div id="bottom_body_wrapper">
			<div id="footer_lose">
			</div>
			
			<div id="footer_menu">
				<ul>
					<li>
						<a href="index.php">On My Way</a>
					</li>
					<li>
						<a href="our_idea.php">Ons Idee</a>
					</li>
					<li>
						<a href="technology.php">Technologie</a>
					</li>
                    <li>
						<a href="news.php">Nieuws</a>
					</li>
					<li>
						<a href="contact.php">Contact</a>
					</li>	
					<li>
						<a href="sign_in.php">Inloggen</a>
					</li>
					
				</ul>
			</div>
			
			<div id="heigh">
				<a data-scroll href="#top_body_wrapper">
					<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Capa_1" x="0px" y="0px" width="30px" height="50px" viewBox="0 0 97.285 97.285" style="enable-background:new 0 0 97.285 97.285;" xml:space="preserve">
						<g>
							<path class="bar" d="M83.952,34.479L50.056,0.585c-0.781-0.781-2.047-0.781-2.828,0L13.333,34.479c-0.781,0.781-0.781,2.047,0,2.828l9.03,9.031   c0.375,0.375,0.883,0.586,1.414,0.586c0.53,0,1.039-0.211,1.414-0.586l14.534-14.532v63.478c0,1.104,0.896,2,2,2H55.56   c1.104,0,2-0.896,2-2V31.807l14.532,14.532c0.75,0.75,2.078,0.75,2.828,0l9.031-9.031c0.375-0.375,0.586-0.884,0.586-1.414   C84.538,35.364,84.327,34.854,83.952,34.479z" fill="#dedede"/>
						</g>
					</svg>
				</a>
			</div>
			
			<div id="social">
                <ul id="socialicons">
                         <li> <a href="https://play.google.com/store" target="_blank" class="playstore footer_icon"><img src="IMG/Social/playstore%20(1).png" title="Download Onze App" alt=""></a></li>
                    <li> <a href="http://www.apple.com/itunes/" target="_blank" class="appstore footer_icon"><img src="IMG/Social/app-store%20(1).png" title="Download Onze App" alt="appstore-icon"> </a></li>
			    </ul>
			</div>
			
			<footer>
				<div id="text_footer">
					&copy Copyright OnMyWay - 2017 | Made by Jesse Bartels, Daan v. Beusekom, Matthijs v. Duin & Thijs v/d Heijden</a>
				</div>
			</footer>
		</div>

	</body>
</html>

<!-- Creators: Daan, Jesse, Matthijs, Thijs -->
<!-- Project: Level 5 -->