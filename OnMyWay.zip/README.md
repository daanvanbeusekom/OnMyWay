# OnMyWay
A repository for the site of a project on school!

##Log:

------------------------------------------
31-01-2017 17:55
### Update 1.1: Add the basic stuff. 
###### The basic stuff is imported, maps are created and you can run the site without a localhost.
--
01-02-2017 20:08
### Update 1.2: The site is now running on php. 
###### The site is now running on php, you have to run the site in a localhost with php support.
--
02-02-2017 10:36
### Update 1.3: The site is now on a Database. 
###### The site is now running on php, you have to run the site in a localhost with php support. You can maken now your account and then you can login.
--
13-02-2017 20:09
### Update 2.0: Add the admin panel. 
###### You can now login as a administrator and you can then update the site (you can change the content). Add Database with administrator tables.
--

14-02-2017 17:04
### Update 2.0: Add the news page. 
###### You can now see the news and you can when you are a administrator update the news or make a new news messages.
--

 
