<?php
//Server account
$db_servername = "localhost";
$db_username = "root";
$db_username2 = "root";
$db_password = "";
$db_name = "onmyway_admin";
$db_name2 = "onmyway_web";
?>