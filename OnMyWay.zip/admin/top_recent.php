				
				<div id="welcome_message">
					<h2> Hier vind je de recente gebeurtenissen.</h2>
					<p> Alleen de belangrijke gebeurtenissen worden weergegeven zoals het configureren van de site.</p>
					<br />
					<div id="recent_static_info" style="-webkit-column-count: 3; /* Chrome, Safari, Opera */ -moz-column-count: 3; /* Firefox */ column-count: 3;">