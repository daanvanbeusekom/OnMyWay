				
				
				<div id="messages_message">
					<h2>Dit is een overzicht van de gerbuikers van het admin-paneel. Je kan ze delete of een mailtje sturen </h2>
					<h2>met hun e-mail adres.</h2>
					
					<div id="txt_messages_message">
						<div id="table-wrapper">
							<div id="table-scroll">
								<table>
									<thead>
										<tr>
											<th>Naam</th>
											<th>E-mail</th>
											<th>leeftijd</th>
											<th>Level</th>
											<th>Delete</th>
										</tr>
									</thead>
									<tbody>

							
