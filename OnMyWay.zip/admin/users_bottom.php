									</tbody>
								</table>
							</div>
						</div>
						
						<br />
						<p> Klik <a href="new_user.php">hier</a> om een nieuwe gebruiker toe tevoegen.</p>
						<br />
						<p> <b>LET OP!!!</b> &nbsp;Admin gebruiker niet verwijderen!</p>
						<br />
						<p> Je kan je profiel bewerken door <a href="user-edit.php?user=<?php echo ''. $_SESSION['user_id'] .'' ; ?>">hier</a> te klikken.</p>
					</div>
				</div>
				
<?php

include "bottom_admin.php"

?>